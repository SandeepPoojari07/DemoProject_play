package services;

import ch.qos.logback.core.net.SyslogOutputStream;
import com.fasterxml.jackson.databind.JsonNode;

import play.libs.ws.WSResponse;
import util.Constants;
import util.EnvironmentConstants;
import util.WsUtil;
import vo.AccessToken;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import play.Logger;
import play.Play;
import play.data.Form;
import play.i18n.Messages;
import play.libs.Json;
import java.util.concurrent.CompletionStage;

import play.mvc.Http.MultipartFormData.FilePart;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.inject.Inject;
import play.api.Configuration;
import util.Constants;
import com.typesafe.config.Config;
import vo.CategoryPickListVO;


public class SFDCServices implements play.libs.ws.WSBodyReadables{


	/*private static Configuration configuration;
	@Inject
	public SFDCServices(Configuration configuration) {
		this.configuration = configuration;
	}*/
	public static AccessToken getSFDCAccessTokenAndInstanceUrl()
	{

	    AccessToken accessToken = new AccessToken();
	    try{

			String url = EnvironmentConstants.sfdc_token_url;
			Map<String, String> tokenreqmap = new HashMap<String, String>();
			tokenreqmap.put(Constants.CLIENT_ID, EnvironmentConstants.client_id);
			tokenreqmap.put(Constants.CLIENT_SECRET, EnvironmentConstants.client_secret);
			tokenreqmap.put(Constants.SFDC_USERNAME,EnvironmentConstants.username);
			tokenreqmap.put(Constants.SFDC_PASSWORD, EnvironmentConstants.password);
			tokenreqmap.put(Constants.GRANT_TYPE, Constants.PASSWORD);

			//CompletionStage<? extends WSResponse> response=WsUtil.post(url, tokenreqmap, null, null);
			//System.out.println("In service response"+response);
			CompletionStage<JsonNode> jsonPromise=
				  WsUtil.post(url, tokenreqmap, null, null).thenApply(r -> r.getBody(instance.json()));
			System.out.print("In Service:"+jsonPromise);
	      accessToken = Json.fromJson(
	      		jsonPromise.toCompletableFuture().get(),
				  AccessToken.class);




	      Logger.debug("ACCESSTOKEN : " + accessToken.getAccess_token());
	    }catch (Exception e){
	      Logger.error("Failed! Bad Request to SFDC" + e);
	    }
	    return accessToken;
	  }

	private static CategoryPickListVO[] getCategoryPickList(String URL, Map header, String strAction) throws JsonParseException, JsonMappingException, IOException{
		CategoryPickListVO[] categoryPickListVOs=null;
		CompletionStage<WSResponse> response = null;
System.out.println("picklist parameters"+URL+header+strAction);
		Map<String, String> reqmap = new HashMap<String, String>();
		reqmap.put("action", strAction);
		CompletionStage<WSResponse> wsresponse = WsUtil.get (
				URL + EnvironmentConstants.getpicklistvalues,
				reqmap, header);

				//.thenApply(r-> r.getBody(instance.json()));;
		CompletionStage<JsonNode> jsonPromise=wsresponse.thenApply(r->r.getBody(instance.json()));
		JsonNode jsonData = jsonPromise.toCompletableFuture().join();
		String data=jsonData.toString();
		System.out.print("In Service:"+jsonPromise);
		System.out.println("Response WS:"+jsonPromise);

		data =data.substring(1, data.length()-1);
		data = data.replaceAll("\\\\\"", "\"");

		System.out.println("Response Data :"+data);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode actualObj = mapper.readValue(data, JsonNode.class);

		categoryPickListVOs = Json.fromJson(actualObj, CategoryPickListVO[].class);
		System.out.println("Category Picklist Vo:"+categoryPickListVOs);
		// Removing String Special Character and " from start and end
		/*jsonResponse =jsonResponse.substring(1, jsonResponse.length()-1);
		jsonResponse = jsonResponse.replaceAll("\\\\\"", "\"");

		System.out.println(jsonResponse);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode actualObj = mapper.readValue(jsonResponse, JsonNode.class);

		categoryPickListVOs = Json.fromJson(actualObj, CategoryPickListVO[].class);
*/

		return categoryPickListVOs;
	}

	public static String refreshPickList()
	{
		String strResponse=null;
		AccessToken access;
		try {
			access = getSFDCAccessTokenAndInstanceUrl();

			Map<String, String> header = new HashMap<String, String>();
			header.put(Constants.AUTHORIZATION,
					Constants.OAUTH + " " + access.getAccess_token());


			CategoryPickListVO[] categoryPickListVOs = getCategoryPickList(access.getInstance_url(), header, Constants.ACT_PICK_LIST_CAT_DOC);



			JsonNode jsonNode = Json.toJson(categoryPickListVOs);
			Logger.debug("Final Pick List "+jsonNode);
			strResponse = jsonNode.toString();
		System.out.println("Pick List Response:"+strResponse);


		} catch (Exception e) {
			Logger.error("Error While Retreiving/Refreshing PickList ",e);
			strResponse = null;
		}
		return strResponse;
	}
	
}
