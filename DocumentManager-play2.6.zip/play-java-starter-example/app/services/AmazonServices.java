package services;

import akka.stream.javadsl.Source;
import akka.util.ByteString;
import com.fasterxml.jackson.databind.JsonNode;
import javassist.bytecode.ByteArray;
import play.libs.ws.WSResponse;
import play.mvc.Http;
import play.mvc.Result;
import util.CommonUtil;
import util.Constants;
import util.EnvironmentConstants;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletionStage;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

//import exception.DocumentException;

import play.Logger;
import play.Play;
import play.mvc.Http.MultipartFormData.FilePart;
import vo.AmazonDocumentBO;
import vo.UploadForm;


import play.Logger;
import util.WsUtil;


public class AmazonServices implements play.libs.ws.WSBodyReadables{


    public static String amazonUrl= EnvironmentConstants.amazon_url;
    public static String amazonUrlProtocol=EnvironmentConstants.amazon_url_protocol;
    public static String amazonSecretKey=EnvironmentConstants.amazon_secret_key;
    public static String cableunit_pathprefix=EnvironmentConstants.amazon_pathprefix_cable_unit;
    public static String constproject_pathprefix=EnvironmentConstants.amazon_pathprefix_construction_project;
    public static String custhierarchy_pathprefix=EnvironmentConstants.amazon_pathprefix_custumer_hierarchy;
    public static String amazonAccessKey = EnvironmentConstants.amazon_access_key;
    public static String bucket_name=EnvironmentConstants.amazon_bucket_name;

    public static String getBucketName() {
        return bucket_name;
    }

    private  static String getDate() {
        String strDate="";

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.AMAZON_DATE_FORMAT,Locale.ENGLISH);
        Date date = new Date(System.currentTimeMillis());
        strDate = simpleDateFormat.format(date);
        return strDate;
    }

    private  static URI getAmazonURI(String strContext)	{
        URI uri = null;
        try {
            uri = new URI(amazonUrlProtocol, amazonUrl, strContext, null);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return uri;
    }

    private static String getSignature(String data) throws NoSuchAlgorithmException, InvalidKeyException {
        Logger.debug("data "+data);
        SecretKeySpec keySpec = new SecretKeySpec(
                amazonSecretKey.getBytes(),
                "HmacSHA1");

        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(keySpec);
        byte[] result = mac.doFinal(data.getBytes());

        String signature = DatatypeConverter.printBase64Binary(result);
        Logger.debug("Signature "+signature);
        return signature;

    }

    private static String getSignatureForData(String strMethod,String strDate, String strResource)
            throws NoSuchAlgorithmException, InvalidKeyException {
        String data = strMethod+"\n\n\n"+strDate+"\n"+strResource;
        return getSignature(data);
    }

    private  static  String getAuthorizationHeaderValue(String signature) {
        return Constants.AUTHORIZATION_PREFIX+" "+amazonAccessKey+":"+signature;
    }

    public static byte[] getDocumentFromAmazon() throws InvalidKeyException, NoSuchAlgorithmException, URISyntaxException
    {
        byte[] byteArr = null;
        String strBucket= getBucketName();
        String pathprefix=cableunit_pathprefix;
        String strContext = "/"+ strBucket;
        //"/" + pathprefix;
try {
    URI uri = new URI(getAmazonURI(strContext).toASCIIString());
    //URI uri = getAmazonURI(strContext);

    String strAmazonUrl = uri.toString();
    Logger.debug("URL for Amazon = " + strAmazonUrl);

    // Fetching the encoded Context to be used in Signature Generation
    String strAmazonContext = uri.getRawPath();
    Logger.debug("Context For Signature = " + strAmazonContext);

    String date = getDate();
    String strSignature = getSignatureForData(Constants.HTTP_GET_METHOD, date, strAmazonContext);
    String strAuthorization = getAuthorizationHeaderValue(strSignature);

    Map<String, String> headerMap = new HashMap<String, String>();
    headerMap.put(Constants.HEADER_DATE, date);
    headerMap.put(Constants.HEADER_AUTHORIZATION, strAuthorization);

    Logger.debug("Header Value for Upload Document " + headerMap);
    System.out.println("Amazon Request:" + strAmazonUrl);
    CompletionStage<? extends WSResponse> wsresponse = WsUtil.get(strAmazonUrl, null, headerMap);


    CompletionStage<Result> result = wsresponse.thenApply(response -> {
        Source<ByteString, ?> body = response.getBodyAsSource();
        System.out.println("Response Status Code:"+response.getStatus()+response.getStatusText());
        // Check that the response was successful
        if (response.getStatus() == 200) {
            System.out.println("Success Response");
            // Get the content type
          return new Result(Http.Status.ACCEPTED);
        } else {
            System.out.println("Error in rponse");
            return new Result(Http.Status.BAD_GATEWAY);
        }
    });

    System.out.println("Amazon Request status :"+result);

    CompletionStage<JsonNode> jsonPromise = wsresponse.thenApply(r -> r.getBody(instance.json()));
    System.out.println("Amazon Response Call:" + jsonPromise);
    JsonNode jsonData = jsonPromise.toCompletableFuture().get();
    //  String data=jsonData.toString();
    System.out.println("Amazon Call:" + jsonData);
}catch(Exception e){
    Logger.error("Error While Uploading File "+e);
}

     //   CompletionStage<JsonNode> jsonPromise=response.thenApply(r -> r.getBody(instance.json()));
      //  int status = jsonPromise
       // Logger.debug("The Response Code "+status);
        /*if( status >= 200 && status < 300){
            byteArr = response.asByteArray();
        }
        else{
            logErrorResponse(response);
            byteArr = response.asByteArray();
        }*/
        return byteArr;
    }



    //Calling upload service

    private static String generateUploadFileName(String strDocumentType, String strActualFileName) {
        String strNewFileName = "";
        String strExtension = CommonUtil.getFileExtension(strActualFileName);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
                Constants.AMAZON_FILE_DATE_FORMAT,Locale.ENGLISH);
        Date date = new Date(System.currentTimeMillis());
        String strDate = simpleDateFormat.format(date);
        strNewFileName = strDocumentType + " " + strDate + strExtension;
        return strNewFileName;
    }


    public static boolean uploaddocumenttest(){

        UploadForm form=new UploadForm();
        form.setCableunitid("60");
        form.setCategorytype("Aftale");
        form.setCreatedby("m72443");
        form.setDepartmentvalue("");
        form.setDocumenttype("Allonge");
        form.setStatustype("Udsednt");
        form.setUserid("m72443");
        form.setDescriptionvalue("Demo Upload");
        form.setUsertype("Admin");

        String fileName="Abcdoc";
        String strFileName = generateUploadFileName(form.getDocumenttype(),fileName);
        File file = new File("C:/Abcdoc.docx");
        FilePart document=new FilePart("abc","Abcdoc","document",file);

        boolean flag=uploadDocumentToAmazon(form,document,strFileName);
        return flag;

    }




    //Upload Document to Amazon Service




    public static boolean uploadDocumentToAmazon(UploadForm form,
                                                 FilePart document, String strFileName) {
        boolean blnUpd = false;
        AmazonDocumentBO amazonDocumentBO = new AmazonDocumentBO();
        amazonDocumentBO.setStrfilename(strFileName);
        amazonDocumentBO.setStrcontenttype(document.getContentType());
        amazonDocumentBO.setStrusernumber(form.getUserid());
        amazonDocumentBO.setStrusertype(form.getUsertype());
        blnUpd = uploadDocument(document.getFile(),
                amazonDocumentBO);
        return blnUpd;
    }

    public static String getPathPrefixBasedOnUserType(String strUserType) {
        String strBucket="";

        if( Constants.USER_TYPE_CABLE_UNIT.equals(strUserType) )
            strBucket=cableunit_pathprefix;
        else if(Constants.USER_TYPE_CONST_PROJECT.equals(strUserType) )
            strBucket=constproject_pathprefix;
        else if(Constants.USER_TYPE_CUST_HIERARCY.equals(strUserType) )
            strBucket=custhierarchy_pathprefix;
        else
            strBucket=cableunit_pathprefix;
        return strBucket;
    }

    private static String getSignatureForUpload(String strMethod,String strContentType,String strDate, String strResource) throws NoSuchAlgorithmException, InvalidKeyException
    {
        String data = strMethod+"\n\n"+strContentType+"\n"+strDate+"\n"+strResource;
        return getSignature(data);
    }

    public static boolean  uploadDocument(Object file, AmazonDocumentBO amazonDocumentBO) {
        boolean blnUpd = false;
        try{
            Logger.debug("Uploading of Document to Amazon Process Started with UserType "+amazonDocumentBO.getStrusertype());
            String strBucket= getBucketName();
            String strPathprefix =getPathPrefixBasedOnUserType(amazonDocumentBO.getStrusertype());
            Logger.debug("Bucket to Used For Uploading File "+strBucket);


            String strContext = "/" +strBucket + "/"+strPathprefix+"/" + amazonDocumentBO.getStrusernumber() +"/" +amazonDocumentBO.getStrfilename();

            // Generating amazon URL with the context
            URI uri = new URI(getAmazonURI(strContext).toASCIIString());
            //URI uri = getAmazonURI(strContext);

            String strAmazonUrl = uri.toString();
            Logger.debug("URL for Amazon = "+strAmazonUrl);

            // Fetching the encoded Context to be used in Signature Generation
            String strAmazonContext = uri.getRawPath();
            Logger.debug("Context For Signature = "+strAmazonContext);

            Logger.debug("The Final URL for Amazon service "+strAmazonUrl);
            String date = getDate();
            String contentType = amazonDocumentBO.getStrcontenttype();
            String strSignature = getSignatureForUpload(Constants.HTTP_PUT_METHOD, contentType, date, strAmazonContext);
            String strAuthorization = getAuthorizationHeaderValue(strSignature);

            Map<String, String> headerMap = new HashMap<String, String>();
            headerMap.put(Constants.HEADER_CONTENT_TYPE, contentType);
            headerMap.put(Constants.HEADER_DATE, date);
            headerMap.put(Constants.HEADER_AUTHORIZATION, strAuthorization);

            Logger.debug("Header Value for Upload Document "+headerMap);

            CompletionStage<? extends WSResponse> wsresponse =  WsUtil.put(strAmazonUrl, null, headerMap, file);
            System.out.println("Upload Response:"+wsresponse);

            CompletionStage<Result> result = wsresponse.thenApply(response -> {
                Source<ByteString, ?> body = response.getBodyAsSource();
                System.out.println("Response Status Code:"+response.getStatus()+response.getStatusText());
                // Check that the response was successful
                if (response.getStatus() == 200) {
                    System.out.println("Success Response");
                    // Get the content type
                    return new Result(Http.Status.ACCEPTED);
                } else {
                    System.out.println("Error in rponse");
                    return new Result(Http.Status.BAD_GATEWAY);
                }
            });

            System.out.println("Amazon Response Status Code:"+result);


        }catch(Exception e){
            Logger.error("Error While Uploading File "+e);
        }
        return blnUpd;
    }






}
