package controllers;

import javassist.bytecode.ByteArray;
import play.mvc.*;
import services.AmazonServices;
import services.SFDCServices;
import views.html.*;
import vo.AccessToken;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {

        //String str=SFDCServices.refreshPickList();
        AccessToken access;
    	access=SFDCServices.getSFDCAccessTokenAndInstanceUrl();
    try {
       boolean arr=AmazonServices.uploaddocumenttest();
        // / byte[] arr = AmazonServices.getDocumentFromAmazon();
        System.out.println("Amazon Response ar:"+arr);
    }catch(Exception e)
    {
        System.out.println(e);
    }
    return ok("Access Token:"+access);
       // return ok(index.render("Your new application is ready."+"***"+access.getAccess_token()+"***"+access.getInstance_url()));
    }

   /* public static searchDocument(){
        Form<SearchForm> search=form(SearchForm.class).bindFromRequest();
        SearchForm sform=search.get();
        return ok(index.render("Success"));
    }
*/
}
