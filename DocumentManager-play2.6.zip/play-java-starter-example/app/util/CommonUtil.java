package util;

public class CommonUtil {


    public static String getFileExtension(String strFileName)
    {
        String strExtension = "";
        if( strFileName != null && strFileName .contains("."))
            strExtension = strFileName.substring(strFileName.lastIndexOf("."));
        if( strExtension == null)
            strExtension = "";
        else
            strExtension = strExtension.trim();

        return strExtension;
    }
}
