package util;

public interface Constants {

	public static final String CABLE_UNIT_TYPE = "cableunit";
	
	public static final String AMAZON_DATE_FORMAT = "EEE, d MMM yyyy HH:mm:ss Z";
	public static final String AMAZON_FILE_DATE_FORMAT = "YYYY-MM-dd-HH-mm-ss";
	
	public static final String HEADER_DATE = "Date" ;
	public static final String HEADER_CONTENT_TYPE = "Content-Type";
	public static final String HEADER_CONTENT_TYPE_JSON = "application/json; charset=UTF-8";
	public static final String HEADER_AUTHORIZATION = "Authorization" ;
	public static final String HTTP_PUT_METHOD = "PUT";
	public static final String HTTP_DELETE_METHOD = "DELETE";
	public static final String HTTP_GET_METHOD = "GET";
	public static final String AUTHORIZATION_PREFIX = "AWS";
	
	public static final String AMAZON_PARAM_KEY_ACCESS_KEY="AWSAccessKeyId";
	public static final String AMAZON_PARAM_KEY_EXPIRES="Expires";
	public static final String AMAZON_PARAM_KEY_SIGNATURE="Signature";
	
	public static final String KEY_AMAZON_ACCESS_KEY = "amazon_access_key";
	public static final String KEY_AMAZON_SECRET_KEY = "amazon_secret_key";
	public static final String KEY_AMAZON_URL = "amazon_url";
	public static final String KEY_AMAZON_URL_PROTOCOL = "amazon_url_protocol";
	public static final String KEY_AMAZON_CABLE_UNIT_PATHPREFIX = "amazon_pathprefix_cable_unit";
	public static final String KEY_AMAZON_CONSTRUCTION_PROJECT_PATHPREFIX = "amazon_pathprefix_construction_project";
	public static final String KEY_AMAZON_CUSTOMER_HIERARCHY_PATHPREFIX = "amazon_pathprefix_custumer_hierarchy";
	
	public static final String USER_TYPE_CABLE_UNIT = "cableunit";
	public static final String USER_TYPE_CONST_PROJECT = "constructionproject"; 
	public static final String USER_TYPE_CUST_HIERARCY = "customerhierarchy";

	public static final String NONCE="nonce";
	public static final String USER_NAME="userName";
	public static final String TEAM="team";
	public static final String DEPARTMENT="department";
	public static final String GROUP="group";
	public static final String COMPANY="company";

	public static final String AD_USER_DOMAIN = "ad_user_domain";
	public static final String AD_PROVIDER_URL = "ad_provider_url";
	public static final String SFDC_TOKEN_URL = "sfdc_token_url";
	public static final String CLIENT_ID = "client_id";
	public static final String CLIENT_SECRET = "client_secret";
	public static final String SFDC_USERNAME = "username";
	public static final String SFDC_PASSWORD = "password";
	public static final String PASSWORD = "password";
	public static final String GRANT_TYPE = "grant_type";
	public static final String SEARCH_CONTEXT = "search_context";
	public static final String AUTHORIZATION = "Authorization";
	public static final String OAUTH = "OAuth";
	public static final String UPLOAD_REST_SERVICE="upload_rest_context";
	public static final String UPLOAD_FILE_SIZE="upload_file_size";
	
	
	public static final String FILENAME = "filename";
	
	public static final String STATUS_ERROR_CODE="errorCode";
	public static final String STATUS_ERROR_MESSAGE="message";
	public static final String STATUS_SUCCESS_MESSAGE="StatusMessage";
	public static final String STATUS_SUCCESS_CODE="StatusCode";
	
	
	public static final String MSGKEY_ERR_MSG_UPL="err_msg_upload";
	public static final String MSGKEY_ERR_MSG_UPL_DOC_NOT_ATT="err_msg_upload_document_not_attached";
	public static final String MSGKEY_ERR_MSG_UPL_USR_NOT_EXIST="err_msg_upload_user_not_exist";
	public static final String MSGKEY_SUC_MSG_UPL="suc_msg_upload";
	public static final String MSGKEY_ERR_MSG_UPL_NO_USER_ID="err_msg_upload_no_user_id";
	public static final String MSGKEY_ERR_MSG_UPL_FILE_SIZE="err_msg_upload_file_size";
	
	public static final String LBLKEY_CABLE_UNIT="lbl_cable_unit";
	public static final String LBLKEY_CONS_PROJ="lbl_cons_proj";
	public static final String LBLKEY_CUST_HIER="lbl_cust_hier";
	
	public static final String SFDC_SUCCESS_CODE = "200";
	public static final String SFDC_NOT_FOUND_CODE = "404";
	public static final String SFDC_ERROR_CODE = "500";
	public static final String MSGKEY_ERR_MSG_SEARCH="err_msg_search";

	public static final String BUCKET_NAME = "amazon_bucket_name";
	
	public static final String LST_USER_LOG_VIEW = "list_user_log_view_auth";
	
	public static final String LOGGER_FOLDER_PATH = "logger_folder_path";
	
	public static final String CLIENT_ID_CALCULAI = "client_id_calculai";
	public static final String CLIENT_SECRET_CALCULAI = "client_secret_calculai";

	public static final String INTRANET = "INTRANET";
	
	public static final String NTLM_PROVIDER = "ntlm_provider";
	public static final String MOBILE_DEVICE="MOBILE";
	public static final String TABLET_DEVICE="TABLET";
	public static final String SUPPORTED_EXTENSION="supp_ext";	
	public static final String EXTN_KEY_PREFIX="extn";
	public static final String DEFAULT_STYLE_CLASS="tif";

	public static final String PDF_EXTENTION = "PDF";
	
	
		
	public static final String PICK_LIST_CONTEXT = "getpicklistvalues";
	public static final String ACT_PICK_LIST_CAT_DOC = "category_documenttypes";
	public static final String ACT_PICK_LIST_CAT_DOC_UPL = "category_documenttypes_upload";
	public static final String ACT_PICK_LIST_DOC_TAG = "documenttag";
	public static final String ACT_PICK_LIST_STATUS = "status";
	
	

	public static final String PL_ITEMS="pick_list_items";
	public static final int NO_ATTEMPT_PICK_LIST=3;
	public static final String PICK_LIST_REFRESH_STATUS="pl_refresh_status";	
	public static final String PICK_LIST_REFRESH_STATUS_SUCCESS="success";
	public static final String PICK_LIST_REFRESH_STATUS_FAILED="failed";	
	
	public static final String LBL_REFRESH_PICKLIST="lbl_refresh_picklist";
	public static final String PICKLIST_ERR_MSG="picklist_refresh_error_message";
	public static final String PICKLIST_LOAD_ERR_MSG="picklist_load_error_message";
	
}
