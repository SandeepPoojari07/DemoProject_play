package util;

public class EnvironmentConstants {

    /**
     * Salesforce OAuth Calls Details
     */
    public static String sfdc_token_url="https://test.salesforce.com/services/oauth2/token";
    public static String client_id="3MVG9Gmy2zmPB01qbsX5TeNwww_FAV1Ynab1G4Bh_eiCkLCbhjM96o450jAa1VQ8d_sBoZXQK3NAtf.Y3vaYg";
    public static String client_secret="8583238296250034460";
    public static String username="kissintegrationuser@yousee.dk.test";
    public static String password="test@YS2017R1JQI6XSli71DguJq5B4x9bt6";
    public static String search_context="/services/apexrest/searchcloudfiles";

    public static String filename="documentmanager.conf";
    public static String getpicklistvalues="/services/apexrest/getpicklistvalues";
    public static String upload_rest_context="/services/apexrest/CloudFileRest";

    /**
     * Amazon Call Details
     */
    public static String amazon_access_key="AKIAJLJR2LEINRG25ANQ";
    public static String amazon_secret_key="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";
    public static String amazon_url_protocol="https";
    public static String amazon_url="s3-eu-west-1.amazonaws.com";
    public static String amazon_pathprefix_cable_unit="preprod/cableunit";
    public static String amazon_pathprefix_construction_project="preprod/construction-project";
    public static String amazon_pathprefix_custumer_hierarchy="preprod/customer-hierarchy";
    public static String amazon_bucket_name="sofus-preprod";




}
