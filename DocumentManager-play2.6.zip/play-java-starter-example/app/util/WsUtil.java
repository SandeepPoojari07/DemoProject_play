package util;

import java.io.File;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.databind.JsonNode;

import play.Logger;
import play.mvc.*;
import play.libs.ws.*;
import java.util.concurrent.CompletionStage;
import play.api.*;
import javax.inject.Inject;
import java.util.List;
import java.util.concurrent.TimeUnit;



public class WsUtil {

	private static long DEFAULT_WAIT=120;
	//private static WSClient ws;
	/*@Inject
	public WsUtil(WSClient ws) {
		this.ws = ws;
	}*/

	static WSClient ws = Play.current().injector().instanceOf(WSClient.class);

	/**
	 * GET Method
	 * @param url
	 * @param reqmap
	 * @param header
	 * @return WSResponse
	 */
	public static CompletionStage<? extends WSResponse> get(String url, Map<String, String> reqmap,
							   Map<String, String> header) {
		WSRequest request=ws.url(url);
		if (null != reqmap)
			setQueryParameter(request, reqmap);
		if (null != header)
			setHeaders(request, header);
		System.out.println("GET Request:"+request);
		CompletionStage<? extends WSResponse> responsePromise=request.execute("GET");
	System.out.println("GET Response:"+responsePromise);
		return responsePromise;
	}


	/**
	 * POST Method
	 * @param url
	 * @param reqmap
	 * @param header
	 * @param data
	 * @return WSResponse
	 */
	public static CompletionStage<? extends WSResponse> post(String url, Map<String, String> reqmap,
			Map<String, String> header, JsonNode data) {


		Logger.debug(url);
		System.out.println("In WS Util:"+url);
		System.out.println("ws:"+ws);


		WSRequest request=ws.url(url);
		System.out.println("Succes req"+request);
		CompletionStage<? extends WSResponse> responsePromise=null;

		System.out.println("request:"+request);
		if (null != reqmap)

			setQueryParameter(request, reqmap);

			//Logger.debug(((JsonNode)data).toString());


		responsePromise = request.execute("POST");

	System.out.print("In WSUTIL Response:"+responsePromise);
		return responsePromise;
	}


	/**
	 * PUT Method
	 * @param url
	 * @param reqmap
	 * @param header
	 * @param data
	 * @return
	 */
	public static CompletionStage<? extends WSResponse> put(String url, Map<String, String> reqmap,
							   Map<String, String> header, Object data) {
		WSRequest req = ws.url(url);
		if (null != reqmap)
			setQueryParameter(req, reqmap);
		if (null != header)
			setHeaders(req, header);

		CompletionStage<? extends WSResponse> responsePromise=null;
		if( data != null)
		{
			if( data instanceof File)
			responsePromise = req.setBody((File)data).execute();
		}
		return responsePromise;
	}


	private static void setHeaders(WSRequest req,
								   Map<String, String> header) {

		for (String key : header.keySet()) {
			req.addHeader(key, header.get(key));
		}
		System.out.println("reqyuest param amazon:"+req);
	}

	private static void setQueryParameter(WSRequest req,
										  Map<String, String> reqmap) {

		for (String key : reqmap.keySet()) {
			req.addQueryParameter(key, reqmap.get(key));
		}
		System.out.println("reqyuest param:"+req);
	}


}

