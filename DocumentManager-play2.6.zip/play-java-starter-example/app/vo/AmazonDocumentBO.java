package vo;

public class AmazonDocumentBO {

    String strusertype;
    String strusernumber;
    String strfilename;
    String strcontenttype;
    public String getStrusertype() {
        return strusertype;
    }
    public void setStrusertype(String strusertype) {
        this.strusertype = strusertype;
    }
    public String getStrusernumber() {
        return strusernumber;
    }
    public void setStrusernumber(String strusernumber) {
        this.strusernumber = strusernumber;
    }
    public String getStrfilename() {
        return strfilename;
    }
    public void setStrfilename(String strfilename) {
        this.strfilename = strfilename;
    }
    public String getStrcontenttype() {
        return strcontenttype;
    }
    public void setStrcontenttype(String strcontenttype) {
        this.strcontenttype = strcontenttype;
    }




}