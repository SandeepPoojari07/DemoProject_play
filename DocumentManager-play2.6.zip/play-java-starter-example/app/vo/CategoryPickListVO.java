package vo;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Comparator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class CategoryPickListVO implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String categoryvalue;


    private String categorylabel;

    public String getCategoryvalue() {
        return categoryvalue;
    }

    public void setCategoryvalue(String categoryvalue) {
        this.categoryvalue = categoryvalue;
    }

    public String getCategorylabel() {
        return categorylabel;
    }

    public void setCategorylabel(String categorylabel) {
        this.categorylabel = categorylabel;
    }


}
