package vo;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/**
 * Created by IntelliJ IDEA.
 * User: m38926
 * Date:  14/5/2013
 * Time: 1:58:09 PM
 * To change this template use File | Settings | File Templates.
 */
 @JsonIgnoreProperties(ignoreUnknown = true)
public class AccessToken implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = -8491295927048500909L;
	    private String id;
        private String issued_at;
        private String instance_url;
        private String signature;
        private String access_token;

    public String getId() {
            return id;
        }
        public void setId(String id) {
            this.id = id;
        }
        public String getIssued_at() {
            return issued_at;
        }
        public void setIssued_at(String issued_at) {
            this.issued_at = issued_at;
        }
        public String getInstance_url() {
            return instance_url;
        }
        public void setInstance_url(String instance_url) {
            this.instance_url = instance_url;
        }
        public String getSignature() {
            return signature;
        }
        public void setSignature(String signature) {
            this.signature = signature;
        }
        public String getAccess_token() {
            return access_token;
        }
        public void setAccess_token(String access_token) {
            this.access_token = access_token;
        }


    @Override
    public String toString() {
        return "AccessToken{" +
                "id='" + id + '\'' +
                ", issued_at='" + issued_at + '\'' +
                ", instance_url='" + instance_url + '\'' +
                ", signature='" + signature + '\'' +
                ", access_token='" + access_token + '\'' +
                '}';
    }


}

 