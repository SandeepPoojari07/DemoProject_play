package vo;

import java.io.Serializable;


public class SearchForm implements Serializable{

    public SearchForm() {
        super();
    }
    public SearchForm(String cableunit, String contructionprjct,
                      String hrychcustomer) {
        super();
        this.cableunitnumber = cableunit;
        this.constructionprojectnumber = contructionprjct;
        this.hierarchicalcustomernumber = hrychcustomer;
    }
    /**
     *
     */
    private static final long serialVersionUID = 4151841752927658111L;
    public String title;
    public String cableunitnumber;
    public String constructionprojectnumber;
    public String hierarchicalcustomernumber;
    public String categories;
    public String documenttype;
    public String startdate;
    public String enddate;
    public String doctag;

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getCableunitnumber() {
        return cableunitnumber;
    }
    public void setCableunitnumber(String cableunitnumber) {
        this.cableunitnumber = cableunitnumber;
    }
    public String getConstructionprojectnumber() {
        return constructionprojectnumber;
    }
    public void setConstructionprojectnumber(String constructionprojectnumber) {
        this.constructionprojectnumber = constructionprojectnumber;
    }
    public String getHierarchicalcustomernumber() {
        return hierarchicalcustomernumber;
    }
    public void setHierarchicalcustomernumber(String hierarchicalcustomernumber) {
        this.hierarchicalcustomernumber = hierarchicalcustomernumber;
    }
    public String getDocumenttype() {
        return documenttype;
    }
    public void setDocumenttype(String documenttype) {
        this.documenttype = documenttype;
    }
    public String getStartdate() {
        return startdate;
    }
    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }
    public String getEnddate() {
        return enddate;
    }
    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }
    public String getCategories() {
        return categories;
    }
    public void setCategories(String categories) {
        this.categories = categories;
    }
    public String getDoctag() {
        return doctag;
    }
    public void setDoctag(String doctag) {
        this.doctag = doctag;
    }





}
