package vo;

import util.Constants;

public class UploadForm {


    public String usertype;
    public String userid;
    public String cableunitid;
    public String documenttype;
    public String statustype;
    public String categorytype;
    public String departmentvalue;
    public String descriptionvalue;
    public String createdby;
    public UploadForm(String usertype, String userid, String documenttype,
                      String statustype, String categorytype, String departmentvalue,
                      String descriptionvalue) {
        super();
        this.usertype = usertype;
        this.userid = userid;
        this.documenttype = documenttype;
        this.statustype = statustype;
        this.categorytype = categorytype;
        this.departmentvalue = departmentvalue;
        this.descriptionvalue = descriptionvalue;
    }
    public UploadForm(String userid, String documenttype,
                      String descriptionvalue,String createdby) {
        super();
        this.usertype =  Constants.USER_TYPE_CABLE_UNIT;
        this.userid = userid;
        this.documenttype = documenttype;
        this.descriptionvalue = descriptionvalue;
        this.createdby=createdby;
    }

    public UploadForm()
    {

    }

    public UploadForm(String departmentvalue)
    {
        this.departmentvalue = departmentvalue;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getDocumenttype() {
        return documenttype;
    }

    public void setDocumenttype(String documenttype) {
        this.documenttype = documenttype;
    }

    public String getStatustype() {
        return statustype;
    }

    public void setStatustype(String statustype) {
        this.statustype = statustype;
    }

    public String getCategorytype() {
        return categorytype;
    }

    public void setCategorytype(String categorytype) {
        this.categorytype = categorytype;
    }

    public String getDepartmentvalue() {
        return departmentvalue;
    }

    public void setDepartmentvalue(String departmentvalue) {
        this.departmentvalue = departmentvalue;
    }

    public String getDescriptionvalue() {
        return descriptionvalue;
    }

    public void setDescriptionvalue(String descriptionvalue) {
        this.descriptionvalue = descriptionvalue;
    }
    public String getCreatedby() {
        return createdby;
    }
    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }
    public String getCableunitid() {
        return cableunitid;
    }
    public void setCableunitid(String cableunitid) {
        this.cableunitid = cableunitid;
    }



}
